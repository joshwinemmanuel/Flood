﻿Imports FireSharp.Config
Imports FireSharp.Response
Imports FireSharp.Interfaces
Imports Newtonsoft.Json

Public Class Form1

    Private fcon As New FirebaseConfig() With
        {
        .AuthSecret = "5DqxG7Wshfx0sSRoj3WOzJcSlRPdGLZimEtTuYi8",
        .BasePath = "https://flood-detector-c9726-default-rtdb.firebaseio.com"
        }

    Private client As IFirebaseClient

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            client = New FireSharp.FirebaseClient(fcon)
        Catch
            MessageBox.Show("there was a problem with your internet")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LiveCall()
    End Sub

    Private Async Sub LiveCall()
        While True
            Await Task.Delay(2000)
            Dim res As FirebaseResponse = Await client.GetAsync("test")
            Dim data As Dictionary(Of String, String) = JsonConvert.DeserializeObject(Of Dictionary(Of String, String))(res.Body.ToString())
            UpdateRTB(data)
        End While
    End Sub

    Private Sub UpdateRTB(ByVal records As Dictionary(Of String, String))
        RichTextBox1.Text = ""
        RichTextBox1.Text += records.ElementAt(0).Value & vbLf

    End Sub

End Class